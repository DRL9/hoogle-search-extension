# hoogle-search-extension
firefox extension for hoogle search
